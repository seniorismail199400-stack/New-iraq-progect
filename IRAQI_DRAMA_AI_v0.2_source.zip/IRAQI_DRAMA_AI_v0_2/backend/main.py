from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from uuid import uuid4

app = FastAPI(title="IRAQI DRAMA AI API", version="0.2.0")
projects = {}

class ProjectIn(BaseModel):
    title: str = Field(min_length=1, max_length=100)
    idea: str = Field(min_length=10, max_length=5000)
    dialect: str = "عراقي"
    episodes: int = Field(default=50, ge=1, le=100)

@app.get("/health")
def health():
    return {"ok": True, "service": "IRAQI DRAMA AI API", "version": "0.2.0"}

@app.post("/projects")
def create_project(data: ProjectIn):
    project_id = str(uuid4())
    projects[project_id] = data.model_dump()
    return {"project_id": project_id, "status": "created", "project": projects[project_id]}

@app.post("/generate/script")
def generate_script(data: ProjectIn):
    # Placeholder: replace with a secure server-side LLM provider integration.
    count = data.episodes
    blocks = []
    for start in range(1, count + 1, 10):
        blocks.append({
            "part": len(blocks) + 1,
            "from_episode": start,
            "to_episode": min(start + 9, count),
            "purpose": "تصعيد الصراع وكشف جزء من السر"
        })
    return {
        "status": "draft_template",
        "notice": "قالب أولي فقط؛ لم يتم استدعاء نموذج ذكاء اصطناعي خارجي.",
        "title": data.title,
        "idea": data.idea,
        "dialect": data.dialect,
        "episode_count": count,
        "season_parts": blocks
    }

@app.post("/generate/video")
def generate_video():
    raise HTTPException(
        status_code=501,
        detail="Video provider is not connected yet. Configure a provider adapter and server-side API credentials first."
    )
