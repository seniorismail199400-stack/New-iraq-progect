# خادم IRAQI DRAMA AI — هيكل أولي

هذا مجلد تأسيسي لواجهة الخادم فقط. لا يحتوي على مفاتيح مزوّدين ولا ينفذ توليد فيديو فعلياً.

## التشغيل
يتطلب Python 3.11:
```bash
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

## نقاط API
- `GET /health` فحص الخادم.
- `POST /projects` إنشاء مشروع.
- `POST /generate/script` طلب إعداد خطة سيناريو أولية.
- `POST /generate/video` محجوز لربط مزوّد فيديو موثوق لاحقاً.

قبل ربط أي مزوّد يجب وضع مفاتيح API في متغيرات بيئة على الخادم فقط، وليس داخل تطبيق Android.
