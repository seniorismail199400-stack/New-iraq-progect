package com.iraqidrama.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DramaApp() }
    }
}

private val Night = Color(0xFF101521)
private val Panel = Color(0xFF1B2638)
private val Gold = Color(0xFFE3B45B)

@Composable
fun DramaApp() {
    var title by remember { mutableStateOf("ظل العائلة") }
    var idea by remember { mutableStateOf("أب يخفي سراً قديماً يهدد مستقبل عائلته، ورسالة غامضة تكشف بداية الصراع.") }
    var dialect by remember { mutableStateOf("عراقي") }
    var episodeCount by remember { mutableStateOf("50") }
    var result by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf(0) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, background = Night, surface = Panel,
        onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Night, bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Movie, null) }, label = { Text("المشروع") })
                NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.VideoLibrary, null) }, label = { Text("الحلقات") })
                NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.RecordVoiceOver, null) }, label = { Text("الصوت") })
            }
        }) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("IRAQI DRAMA AI", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("استوديو صناعة المسلسلات بالذكاء الاصطناعي", color = Color.LightGray, fontSize = 13.sp)
                when (selectedTab) {
                    0 -> {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("إنشاء مسلسل جديد", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                FieldLabel("اسم المسلسل")
                                DarkField(title, { title = it }, "اسم المسلسل")
                                FieldLabel("فكرة المسلسل")
                                DarkField(idea, { idea = it }, "اكتب فكرة المسلسل", true)
                                FieldLabel("اللهجة")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilterChip(selected = dialect == "عراقي", onClick = { dialect = "عراقي" }, label = { Text("عراقي") })
                                    FilterChip(selected = dialect == "فصحى", onClick = { dialect = "فصحى" }, label = { Text("فصحى") })
                                }
                                FieldLabel("عدد الحلقات")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("10", "30", "50").forEach {
                                        FilterChip(selected = episodeCount == it, onClick = { episodeCount = it }, label = { Text(it) })
                                    }
                                }
                                Button(
                                    onClick = {
                                        result = buildPlan(title, idea, dialect, episodeCount.toIntOrNull() ?: 50)
                                    },
                                    modifier = Modifier.fillMaxWidth().height(54.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)
                                ) {
                                    Icon(Icons.Default.AutoAwesome, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("إنشاء خطة المسلسل", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        if (result.isNotBlank()) {
                            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("خطة الإنتاج الأولية", color = Gold, fontWeight = FontWeight.Bold)
                                    Text(result, fontSize = 13.sp, lineHeight = 20.sp)
                                    Text("هذه خطة نصية محلية تجريبية وليست فيديو مولّداً.", color = Color(0xFFFFD18A), fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    1 -> InfoPanel("إدارة الحلقات", "ستظهر هنا الحلقات وحالة إنتاج كل حلقة بعد ربط خادم التوليد. النسخة الحالية لا تنشئ فيديو بعد.")
                    else -> InfoPanel("استوديو الأصوات", "سيُضاف توليد الحوار والأصوات ومزامنة الشفاه بعد إعداد وربط مزوّد الصوت الآمن.")
                }
                Text("الإصدار 0.2.0 • نسخة تأسيسية", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun FieldLabel(text: String) { Text(text, color = Gold, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }

@Composable
private fun DarkField(value: String, onChange: (String) -> Unit, hint: String, multiline: Boolean = false) {
    Box(Modifier.fillMaxWidth().background(Color(0xFF263449), RoundedCornerShape(12.dp)).padding(12.dp)) {
        if (value.isEmpty()) Text(hint, color = Color.Gray, fontSize = 14.sp)
        BasicTextField(
            value = value, onValueChange = onChange,
            modifier = Modifier.fillMaxWidth().heightIn(min = if (multiline) 100.dp else 24.dp),
            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp, lineHeight = 21.sp),
            maxLines = if (multiline) 5 else 1
        )
    }
}

@Composable
private fun InfoPanel(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(body, color = Color.LightGray, lineHeight = 22.sp)
            LinearProgressIndicator(progress = { 0f }, modifier = Modifier.fillMaxWidth(), color = Gold)
            Text("بانتظار ربط محرك الإنتاج", color = Color.Gray, fontSize = 12.sp)
        }
    }
}

private fun buildPlan(title: String, idea: String, dialect: String, count: Int): String {
    val parts = (count + 9) / 10
    return buildString {
        appendLine("المسلسل: $title")
        appendLine("الفكرة: $idea")
        appendLine("اللهجة: $dialect")
        appendLine("عدد الحلقات: $count")
        appendLine()
        appendLine("تقسيم الموسم:")
        for (p in 1..parts) {
            val start = (p - 1) * 10 + 1
            val end = minOf(p * 10, count)
            appendLine("الجزء $p: الحلقات $start إلى $end")
        }
        appendLine()
        appendLine("قالب كل حلقة:")
        appendLine("1. افتتاحية تشد الانتباه.")
        appendLine("2. تقديم مشكلة أو سر.")
        appendLine("3. تصاعد الصراع والحوار.")
        appendLine("4. لحظة عاطفية أو مواجهة.")
        appendLine("5. نهاية معلّقة تشجع على مشاهدة الحلقة التالية.")
    }
}
